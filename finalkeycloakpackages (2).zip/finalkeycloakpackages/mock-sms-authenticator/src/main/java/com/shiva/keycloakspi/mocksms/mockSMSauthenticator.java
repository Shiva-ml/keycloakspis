package com.shiva.keycloakspi.mocksms;

import jakarta.ws.rs.core.Response;
import org.keycloak.authentication.AuthenticationFlowContext;
import org.keycloak.authentication.AuthenticationFlowError;
import org.keycloak.authentication.Authenticator;
import org.keycloak.models.KeycloakSession;
import org.keycloak.models.RealmModel;
import org.keycloak.models.UserModel;

public class mockSMSauthenticator implements Authenticator {

    private static final String TPL_CODE = "login-sms.ftl";
    private UserService userService;

    public mockSMSauthenticator(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void authenticate(AuthenticationFlowContext context) {
        KeycloakSession session = context.getSession();
        UserModel user = context.getUser();
        String mobile = "";
        mobile = context.getUser().getFirstAttribute("mobile");


        try {
            boolean rtn= userService.generateuserotp(mobile);
        } catch (Exception e) {
            context.failureChallenge(AuthenticationFlowError.INTERNAL_ERROR,
                    context.form().setError("smsAuthSmsNotSent", "Error. Use another method.")
                            .createErrorPage(Response.Status.INTERNAL_SERVER_ERROR));
        }

        context.challenge(context.form().createForm(TPL_CODE));

    }

    @Override
    public void action(AuthenticationFlowContext context) {
        String enteredCode = context.getHttpRequest().getDecodedFormParameters().getFirst("code");

        if (enteredCode == null || enteredCode.trim().isEmpty()) {
            context.failureChallenge(AuthenticationFlowError.INVALID_CREDENTIALS,
                    context.form().setError("otp cannot be empty. Please enter your otp.").createForm(TPL_CODE));
            return;
        }

        KeycloakSession session = context.getSession();
        UserModel user = context.getUser();
        String mobile = "";
        mobile = context.getUser().getFirstAttribute("mobile");


        boolean rtn= userService.verifyuserotp(mobile,enteredCode);

        if (rtn) {
            context.success();
        } else {
            context.failureChallenge(AuthenticationFlowError.INVALID_CREDENTIALS,
                    context.form().setError("Invalid otp. Please try again.").createForm(TPL_CODE));
        }
    }


@Override
public boolean requiresUser() {
    return true;
}

@Override
public boolean configuredFor(KeycloakSession session, RealmModel realm, UserModel user) {
    return true;
}

@Override
public void setRequiredActions(KeycloakSession session, RealmModel realm, UserModel user) {
}

@Override
public void close() {
}

}


