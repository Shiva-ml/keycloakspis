package com.shiva.keycloakspi.mocksms;

import java.util.List;

import org.jboss.logging.Logger;
import org.keycloak.models.KeycloakSession;
import org.keycloak.broker.provider.util.SimpleHttp;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.ws.rs.core.Response;

public class UserService {

    private final KeycloakSession session;
    private static final Logger LOGGER = Logger.getLogger(UserService.class);

    public UserService(KeycloakSession session) {
        this.session = session;
    }

    public boolean generateuserotp(String mobile) {
        boolean verified = false;
        try {
            SimpleHttp.Response response = SimpleHttp.doPost("http://localhost:8081/users/generate-otp", session)
                    .param("mobile",mobile)
                    .header("Content-Type", "application/x-www-form-urlencoded")  // Set the content type to form-urlencoded
                    .asResponse();  // Send the request and get the response

            if (response.getStatus() == Response.Status.OK.getStatusCode()) {
                verified = true;

            }
        } catch (Exception e) {
            LOGGER.error("unable to communicate to mock service to generate otp", e);
        }
        return verified;
    }

    public boolean verifyuserotp(String mobile, String otp) {
        boolean verified = false;
        try {
            SimpleHttp.Response response = SimpleHttp.doPost("http://localhost:8081/users/verify-otp", session)
                    .param("mobile",mobile)  // Add form parameter
                    .param("otp", otp)  // Add form parameter
                    .header("Content-Type", "application/x-www-form-urlencoded")  // Set the content type to form-urlencoded
                    .asResponse();  // Send the request and get the response

            if (response.getStatus() == Response.Status.OK.getStatusCode()) {
                verified = true;
            }
        } catch (Exception e) {
            LOGGER.error("Error verifying user otp", e);
        }
        return verified;
    }

}