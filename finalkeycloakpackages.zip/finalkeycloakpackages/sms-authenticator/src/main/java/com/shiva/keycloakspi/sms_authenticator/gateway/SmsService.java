
package com.shiva.keycloakspi.sms_authenticator.gateway;

public interface SmsService {

	void send(String phoneNumber, String message);

}
